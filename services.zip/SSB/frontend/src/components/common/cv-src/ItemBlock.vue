<template>
<div></div>
</template>

<script>
export default {
  name: "ItemBlock"
}
</script>

<style scoped>

</style>