module.exports = {
    publicPath: '/'
}
