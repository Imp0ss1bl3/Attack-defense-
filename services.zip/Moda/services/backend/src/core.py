private_key = open("keys/private.pem", "r").read()
public_key = open("keys/public.pem", "r").read()